function [nodes,weights] = UnivariateRule(n,lbnd,ubnd)
% Univariate quadrature rule
% We will use nested Clenshaw-Curtis rules in [lbnd,ubnd] s.t.
%   n = 1  =>  1-pt rule;
%   n > 1  => 2^(n-1)+1 pt rule.

if n == 1
    nodes = 0; % midpoint of interval [-1,1]
    weights = 2; % length of interval [-1,1]
else
    N = 2^(n-1)+1; % number of nodes of level n CC rule
    nodes = -cos(pi*(0:N-1)./(N-1)); % nodes of CC rule
    tmp = zeros(1,N);
    tmp(1:2:N) = [2,2./(1-(2:2:N-1).^2)]; % Chebyshev coefficients
    tmp = real(ifft([tmp,tmp(end-1:-1:2)]));
    tmp(2:N-1) = 2*tmp(2:N-1);
    weights = tmp(1:N);
end

% Affine mapping from [-1,1] to [lbnd,ubnd].
nodes = .5*(ubnd-lbnd)*nodes+.5*(lbnd+ubnd);

% The weights should be scaled so that their sum equals the length of the 
% interval [lbnd,ubnd].
weights = .5*(ubnd-lbnd)*weights;
