% Written by Vesa Kaarnioja on 14.10.2019 at University of Mannheim.
% Modified 1.9.2023 by Vesa Kaarnioja

% An implementation of the Smolyak-Clenshaw-Curtis quadrature rule using
% the combination method.
function [snodes2,sweights2] = SmolyakRule(d,k,lbnd,ubnd)
% Checklist before we start: what do we need?
%  - A generator of univariate quadrature rules.
%    * See: UnivariateRule.m (Clenshaw-Curtis quadrature rule)
%  - A way to compute tensor products.
%    * See: CombineVectors.m and CombineWeights.m
%  - A way to generate multi-indices.
%    * See: NextComposition.m

% Smolyak quadrature parameters:
% Let's generate the univariate quadrature data.
% Create a data structure, where we label the quadrature
% nodes as 'nodes' and weights as 'weights'.
nw = struct('nodes',[],'weights',[]);

% Compute the necessary quadrature data.
for ii = 1:k-d+1
  [nodes,weights] = UnivariateRule(ii,lbnd,ubnd);
  nw(ii).nodes = nodes;
  %nw(ii).nodes = sparse(nodes); % Life hack: for symmetric rules, one can 
                                 % use the 'sparse' format here! However,
                                 % do _not_ use combvec in this case! 
  nw(ii).weights = weights;
end

snodes = []; % initialize an array for Smolyak nodes
sweights = []; % initialize an array for Smolyak weights

% Loop over l = max(d,k-d+1),...,k.
for l = max(d,k-d+1):k
  % Handle the special case sum(alpha) == d separately.
  if l == d
    snodes = repmat(nw(1).nodes,d,1);
    sweights = prod(repmat(nw(1).weights,d,1));
    sweights = (-1)^(k-l)*nchoosek(d-1,k-l)*sweights;
  else
    % Initialize the multi-index alpha.
    alpha = ones(1,d);
    alpha(1) = l-d+1;
    count = nchoosek(l-1,d-1); % == #{alpha; sum(alpha) == l}
    
    % Loop over all multi-indices alpha with sum(alpha) == l, l fixed.
    for ii = 1:count
      % Generate the rule U_{alpha_1}
      tmpnodes = nw(alpha(1)).nodes; % the nodes of rule U_{alpha_1}
      tmpweights = nw(alpha(1)).weights; % the corresponding weights
      for jj = 2:d
        % Generate the rule U_{alpha_jj}
        tmpnodes2 = nw(alpha(jj)).nodes;
        tmpweights2 = nw(alpha(jj)).weights;
        
        % Compute U_{alpha_1} (x) ... (x) U_{alpha_jj}
        tmpnodes = CombineVectors(tmpnodes,tmpnodes2);
        % tmpnodes = combvec(tmpnodes,tmpnodes2); % alternative method using NNT toolbox
        tmpweights = CombineWeights(tmpweights,tmpweights2);
        % tmpweights = prod(combvec(tmpweights,tmpweights2)); % alternative method using NNT toolbox
      end
      
      % After this loop, tmpnodes should contain the nodes of
      % U_{alpha_1} (x) ... (x) U_{alpha_d} and tmpweights contains
      % the corresponding weights of that quadrature rule.
      % Use the correction term to update the weights.
      tmpweights = (-1)^(k-l)*nchoosek(d-1,k-l)*tmpweights;
      
      % Append the temporary nodes and weights to arrays
      % 'snodes' and 'sweights'.
      snodes = [snodes,tmpnodes];
      sweights = [sweights,tmpweights];
      if ii < count
        alpha = NextComposition(alpha);
      end
    end
  end
end

% Remove duplicate nodes and sum up the corresponding quadrature weights.
[~,I] = uniquetol(snodes','ByRows',1e-12);
snodes2 = snodes(:,I);
sweights2 = [];
for ii = 1:length(I)
    ind = find(sum(abs(snodes2(:,ii)-snodes))<1e-12);
    sweights2(ii) = sum(sweights(ind));
end

