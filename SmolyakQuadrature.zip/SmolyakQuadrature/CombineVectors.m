function res = CombineVectors(vec1,vec2)
% Compute the outer product of vectors vec1 and vec2.

siz1 = size(vec1,2);
siz2 = size(vec2);

res = [kron(vec1,ones(size(vec2)));repmat(vec2,1,siz1)];