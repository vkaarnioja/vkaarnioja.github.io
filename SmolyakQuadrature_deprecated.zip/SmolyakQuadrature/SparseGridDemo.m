% Written by Vesa Kaarnioja on 21.10.2019 at University of Mannheim.

% Let us demonstrate generalized sparse grid quadratures.

% For this demonstration, we fix Clenshaw-Curtis rules as our univariate
% quadrature rule sequence.

d = 3;
lbnd = -1; ubnd = 1; % domain [-1,1]^d

% We are interested in computing the sparse grid quadrature over some
% (arbitrary) index set 'alphablock'. In practice, one can either use a 
% priori knowledge to tailor the index set to fit the integrand, or one
% can construct the index set during run-time -- the latter is the basis
% for dimension-adaptive algorithms. (See, e.g., Gerstner and Griebel,
% 2003).

% Let us construct the Smolyak index set and compare our results to
% 'SmolyakRule.m'. Note that if you are using an arbitrary index set, in 
% practice you need the index set to be admissible (this condition is, of
% course, automatically satisfied for the Smolyak index set of multi-
% indices with total degree less than or equal to k).
k = 6;
alphablock = ones(1,d);
for l = d+1:k
  count = nchoosek(l-1,d-1);
  alpha = ones(1,d);
  alpha(1) = l-d+1;
  for ii = 1:count
    alphablock = [alphablock;alpha];
    if ii < count
      alpha = NextComposition(alpha);
    end 
  end
end

snodes = []; sweights = [];

for ii = 1:size(alphablock,1)
  alpha = alphablock(ii,:);
  % Construct Delta_{alpha_1}. 
  [nodes,weights] = UnivariateRule(alpha(1),lbnd,ubnd);
  % If alpha(1) == 1, then Delta_1 = U_1 and we are done.
  if alpha(1) == 2
    % If alpha(1) == 1, then the second node of the level 2 CC rule
    % coincides with single node of the level 1 CC rule.
    [~,weights2] = UnivariateRule(alpha(1)-1,lbnd,ubnd);
    weights(2) = weights(2) - weights2;
  elseif (alpha(1) > 2)
    % If l > 1, then every other node of the level l CC rule coincides
    % with the nodes of the level l-1 CC rule.
    [~,weights2] = UnivariateRule(alpha(1)-1,lbnd,ubnd);
    weights(1:2:end) = weights(1:2:end) - weights2;
  end
  % Next we construct Delta_{alpha_2},...,Delta_{alpha_d} analogously to
  % the first case and compute the tensor product 
  % Delta_{alpha_1} (x) ... (x) Delta_{alpha_d} (compare with Smolyakrule.m). 
  for jj = 2:d
    [tmpnodes,tmpweights] = UnivariateRule(alpha(jj),lbnd,ubnd);
    if (alpha(jj) == 2)
      [~,tmpweights2] = UnivariateRule(alpha(jj)-1,lbnd,ubnd);
      tmpweights(2) = tmpweights(2) - tmpweights2;
    elseif (alpha(jj) > 2)
      [~,tmpweights2] = UnivariateRule(alpha(jj)-1,lbnd,ubnd);
      tmpweights(1:2:end) = tmpweights(1:2:end) - tmpweights2;
    end
    nodes = combvec(nodes,tmpnodes);
    weights = prod(combvec(weights,tmpweights));
  end
  snodes = [snodes,nodes];
  sweights = [sweights,weights];
end
fun = @(x) prod(x.^2);
dot(sweights,fun(snodes)) % The result should coincide with SmolyakRule.m
                          % when using the same values of d and k.
