function res = NextComposition(c);
% Given a multi-index c, find the next multi-index with the same 1-norm as
% c (i.e., the sum of all elements of the multi-index remains invariant) in
% lexicographical order. This algorithm is from Steven S. Skiena's book:
% "Implementing Discrete Mathematics: Combinatorics and Graph Theory with
% Mathematica" (1990).

h = 1;
while (c(h) == 1)
  h = h+1;
end
t = c(h); c(h) = 1;
c(1) = t-1; c(h+1) = c(h+1)+1;
res = c;
