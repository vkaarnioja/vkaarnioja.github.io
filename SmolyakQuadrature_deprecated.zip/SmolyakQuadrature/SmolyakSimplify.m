% Added 21.10.2019.
function [nodes,weights] = SmolyakSimplify(snodes,sweights)
% Input: output of 'SmolyakRule.m'.
% This function deletes the duplicate elements in 'snodes' and sums the
% corresponding weights in 'sweights'.

% Sort array 'snodes' so that duplicate nodes are adjacent to each other.
[nodes,ord] = sortrows(snodes');

% Order the array 'sweights' so that each element is paired with the
% corresponding node in 'snodes'.
weights = sweights(:,ord)';

ord2 = 1;
count = 1;
for jj = 2:size(nodes,1)
  if abs(nodes(jj,:)-nodes(jj-1,:)) < 1e-12 
    % For duplicate rows in 'snodes', sum the corresponding weights.
    weights(count) = weights(count) + weights(jj);
  else
    % Otherwise, keep track of the unique elements in 'snodes'.
    count = jj;
    ord2 = [ord2;jj];
  end
end
nodes = nodes(ord2,:)'; % Unique Smolyak nodes without duplicates
weights = weights(ord2)'; % Corresponding weights
