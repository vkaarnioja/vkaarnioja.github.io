function res = CombineWeights(vec1,vec2)
% Compute the outer product of vectors vec1 and vec2
% and perform component-wise multiplication.

siz1 = size(vec1,2);
siz2 = size(vec2);

res = prod([kron(vec1,ones(size(vec2)));repmat(vec2,1,siz1)]);
